BYnotification = 'notification_email.html'
from_address = 'noreply@omnilogistics.com'
to_address = ['drew@sightlinefreight.com','thomas@sightlinefreight.com','bestbuy@livelogisticscorp.com']

