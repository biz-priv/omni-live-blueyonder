clientID = 'livelogisticsSRfiJVNFmE-595ce6734bf99d18'
tokenURL = 'https://lctluminettst01-api.jdadelivers.com/api/oauth/token'
responseURL = 'https://lctluminettst01-api.jdadelivers.com/api/v1/dynamicCapacity/quoteResponse'
