clientID = 'livelogisticsqhbvXYftNo-7399a6c9df44d38a'
tokenURL = 'https://lctluminetprd01-api.jdadelivers.com/api/oauth/token'
responseURL = 'https://lctluminetprd01-api.jdadelivers.com/api/v1/dynamicCapacity/quoteResponse'
